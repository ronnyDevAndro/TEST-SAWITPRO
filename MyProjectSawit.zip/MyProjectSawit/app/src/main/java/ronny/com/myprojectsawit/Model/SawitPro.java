package ronny.com.myprojectsawit.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class SawitPro implements Parcelable {
    String textPicture,ditance,estimated;

    public String getTextPicture() {
        return textPicture;
    }

    public void setTextPicture(String textPicture) {
        this.textPicture = textPicture;
    }

    public String getDitance() {
        return ditance;
    }

    public void setDitance(String ditance) {
        this.ditance = ditance;
    }

    public String getEstimated() {
        return estimated;
    }

    public void setEstimated(String estimated) {
        this.estimated = estimated;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.textPicture);
        dest.writeString(this.ditance);
        dest.writeString(this.estimated);
    }

    public void readFromParcel(Parcel source) {
        this.textPicture = source.readString();
        this.ditance = source.readString();
        this.estimated = source.readString();
    }

    public SawitPro() {
    }

    protected SawitPro(Parcel in) {
        this.textPicture = in.readString();
        this.ditance = in.readString();
        this.estimated = in.readString();
    }

    public static final Parcelable.Creator<SawitPro> CREATOR = new Parcelable.Creator<SawitPro>() {
        @Override
        public SawitPro createFromParcel(Parcel source) {
            return new SawitPro(source);
        }

        @Override
        public SawitPro[] newArray(int size) {
            return new SawitPro[size];
        }
    };
}
