package ronny.com.myprojectsawit.Helper;

import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import ronny.com.myprojectsawit.R;

public class Util {
    public static void setToolbar(AppCompatActivity appCompatActivity, String title, boolean remark) {
        Toolbar toolbar = appCompatActivity.findViewById(R.id.toolbar);
        appCompatActivity.setSupportActionBar(toolbar);
        TextView mTitle = toolbar.findViewById(R.id.toolbar_title);
        mTitle.setText(title);
        if (appCompatActivity.getSupportActionBar() != null) {
            appCompatActivity.getSupportActionBar().setDisplayShowTitleEnabled(false);
            if (!remark) {
                appCompatActivity.getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
            appCompatActivity.getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }
}
