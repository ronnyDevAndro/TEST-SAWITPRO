package ronny.com.myprojectsawit.UI.DetailText;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import ronny.com.myprojectsawit.Config.Config;
import ronny.com.myprojectsawit.Helper.Util;
import ronny.com.myprojectsawit.Model.SawitPro;
import ronny.com.myprojectsawit.R;

public class DetailText extends AppCompatActivity {
    TextView tvResult,tvDistance,tvEstimated;
    SawitPro sawitPro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_text);
        Util.setToolbar(this, getString(R.string.detail), false);
        sawitPro = getIntent().getParcelableExtra(Config.PARCELABLE);
        tvResult = findViewById(R.id.tv_result);
        tvDistance = findViewById(R.id.tv_distance);
        tvEstimated = findViewById(R.id.tv_estimated);

        tvResult.setText(sawitPro.getTextPicture());
        tvEstimated.setText(sawitPro.getEstimated());
        tvDistance.setText(sawitPro.getDitance());

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}