package ronny.com.myprojectsawit.UI.AddPicture;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import ronny.com.myprojectsawit.BuildConfig;
import ronny.com.myprojectsawit.Config.Config;
import ronny.com.myprojectsawit.Helper.LocationTrack;
import ronny.com.myprojectsawit.Helper.Util;
import ronny.com.myprojectsawit.Model.SawitPro;
import ronny.com.myprojectsawit.R;
import ronny.com.myprojectsawit.UI.DetailText.DetailText;

public class AddPicture extends AppCompatActivity implements View.OnClickListener {

    Button btnTakePicture, btnSave, btnDetail;
    Bitmap bitmap;
    LocationTrack locationTrack;
    TextView tvResult;
    String yourDistance, yourDuration;
    SawitPro sawitPro;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_picture);
        Util.setToolbar(this, getString(R.string.add_picture), true);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference("SawitInfo");
        sawitPro = new SawitPro();
        locationTrack = new LocationTrack(this);
        locationTrack.canGetLocation();
        btnTakePicture = findViewById(R.id.take_picture);
        btnSave = findViewById(R.id.save);
        btnDetail = findViewById(R.id.detail);
        tvResult = findViewById(R.id.tv_result);
        btnTakePicture.setOnClickListener(this);
        btnDetail.setOnClickListener(this);
        btnSave.setOnClickListener(this);

    }

    private void getLocation() {
        String yourLoc = locationTrack.getLatitude() + "," + locationTrack.getLongitude();
        String targetLoc = -6.193689036176128 + "," + 106.82201984137892;
        AndroidNetworking.get(Config.URL)
                .addQueryParameter("origin", yourLoc)
                .addQueryParameter("destination", targetLoc)
                .addQueryParameter("mode", "driving")
                .addQueryParameter("key", BuildConfig.API_KEY)
                .setPriority(Priority.HIGH)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray routes = response.getJSONArray("routes");
                            JSONObject firstElement = (JSONObject) routes.get(0);
                            JSONArray ar = (JSONArray) firstElement.get("legs");
                            for (int i = 0; i < ar.length(); i++) {
                                JSONObject json = ar.getJSONObject(i);
                                JSONObject distance = (JSONObject) json.get("distance");
                                yourDistance = distance.getString("text");

                                JSONObject duration = (JSONObject) json.get("duration");
                                yourDuration = duration.getString("text");

                                Log.d("result", yourDistance);
                                Log.d("result", yourDuration);
                            }
                            String result = tvResult.getText().toString();
                            saveFirebase(result, yourDistance, yourDuration);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError error) {


                    }
                });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.take_picture) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (intent.resolveActivity(getPackageManager()) != null) {
                takePicture.launch(intent);
                btnDetail.setVisibility(View.GONE);
            } else {
                Toast.makeText(this, "There is no app that support this action",
                        Toast.LENGTH_SHORT).show();
            }
        } else if (v.getId() == R.id.save) {
            if (bitmap == null) {
                Toast.makeText(AddPicture.this, "You Must Take Picture ", Toast.LENGTH_SHORT).show();
            } else {
                getLocation();
            }
        } else if (v.getId() == R.id.detail) {
            Intent intent = new Intent(AddPicture.this, DetailText.class);
            intent.putExtra(Config.PARCELABLE, sawitPro);
            startActivity(intent);
        }

    }

    private void saveFirebase(String textField, String distance, String estimated) {


        sawitPro.setTextPicture(textField);
        sawitPro.setDitance(distance);
        sawitPro.setEstimated(estimated);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                databaseReference.setValue(sawitPro);
                btnDetail.setVisibility(View.VISIBLE);
                Toast.makeText(AddPicture.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(AddPicture.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    ActivityResultLauncher<Intent> takePicture = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        Intent data = result.getData();
                        bitmap = (Bitmap) data.getExtras().get("data");
                        imageFromBitmap(bitmap);
                    } else {
                        Toast.makeText(AddPicture.this, "Cancelled...", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    private void imageFromBitmap(Bitmap bitmap) {
        int rotationDegree = 0;
        InputImage image = InputImage.fromBitmap(bitmap, rotationDegree);
        recognizeText(image);
    }

    private void recognizeText(InputImage image) {
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        recognizer.process(image)
                .addOnSuccessListener(new OnSuccessListener<Text>() {
                    @Override
                    public void onSuccess(Text visionText) {
                        String text = visionText.getText();
                        tvResult.setText(text);
                    }
                })
                .addOnFailureListener(
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                // Task failed with an exception
                                // ...
                            }
                        });
    }


}