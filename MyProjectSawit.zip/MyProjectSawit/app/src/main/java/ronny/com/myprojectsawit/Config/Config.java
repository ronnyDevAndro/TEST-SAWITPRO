package ronny.com.myprojectsawit.Config;

import ronny.com.myprojectsawit.BuildConfig;

public class Config {

    public static final String URL = BuildConfig.BASE_URL + "maps/api/directions/json";
    public static final String PARCELABLE = "PARCELABLE";
}
